/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadoramat;
import view.TelaPrincipal;


/**
 *
 * @author jhessikkaelly
 */
public class CalculadoraMat {

    public static void main(String[] args) {
        // criando objeto da tela da calculadora
        TelaPrincipal tela = new TelaPrincipal();
        // deixando a tela visivel
        tela.setVisible(true);
    }
}
